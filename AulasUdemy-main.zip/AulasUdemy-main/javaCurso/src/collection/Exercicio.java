package collection;

public class Exercicio {
	public static void main(String[] args) {
//		1a collection - SET
//		Não ordenado(PODE SER ORDENADO), não indexado e não aceita repetição e objetos duplicados.
		
//		2a collection - LIST
//		Indexada, aceita repetição
		
//		3a collection - MAP
//		Chave/Valor ,  Chave não aceita repetição, Valor aceita repetição
			
//		4a collection - QUEUE
//		FIFO - First In First Out - Primeiro dado a entrar, é o primeiro a sair.
		
//		5a collection - Stack
//		LIFO - Last In Last Out - Último a entrar, é o primeiro a sair.
		
//		Função ADD para adicionar
//		Função Size para ver o tamanho da lista
		
//		
		
	}
}
