package oo.heranca;

public class Monstro extends Jogador{

    Monstro() {
        super(11, 10);
    }
//    Ele pode ser um monstro também, Jogador, ou Heroi. Todos tem posição X, Y,
//    podem atacar, se movimentar.
//    Tem vida. Pois tem HERANÇA. A Classe Genérica ,
//    transmite atributos para a classe FILHA (Extends JOGADOR)


}
