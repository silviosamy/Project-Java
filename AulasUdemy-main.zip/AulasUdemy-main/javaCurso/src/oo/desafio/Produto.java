package oo.desafio;

public class Produto {

	String nome;
	double preco;
	
	Produto(String nome, double preco) {
	
		this.nome = nome;
		this.preco = preco;
	}
}
