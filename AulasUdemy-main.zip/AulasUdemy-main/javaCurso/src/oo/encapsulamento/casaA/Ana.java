package oo.encapsulamento.casaA;

public class Ana {

    private String segredo = "..."; // privado(private)
    String facoDentroDeCasa = "..."; // default ou pacote
    protected String formaDeFalar = "..."; // Class do mesmo package ou por herança
    public String todosSabem = "...";
}
