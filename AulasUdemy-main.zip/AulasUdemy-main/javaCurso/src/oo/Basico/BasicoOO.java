package oo.Basico;

public class BasicoOO {

//    Classes: é um conjunto de objetos, que possuem uma ou mais características em comum
//    Objeto é um elemento que pertence a uma classe.
//    Atributos é um conjunto de características de um determinado objeto.
//    Métodoo é o que permite modificar os atributos de um determinado objeto.
//    Temos também a Herança, Polimorfismo, sobrecarga, Encapsulamento
//    que são também princípios básicos da POO.
//    Polimorfismo : Varias classes derivadas de 1 mesma superclass, que pode invocar métodos
//    que tem a mesma identificação, mas comportamentos diferentes.
//    Ex : Class Funcionario (String "Nome", int idade) Nas subclasses:
//    Diretor, Gerente, Vendedor, todos tem Nome e Idade, utilizando 1 uníco métodoo.

}
