package Training;

public class Util {

    public CarBrand newBrand(String name) {
        return new CarBrand(name);
    }

    public CarModel newModel(String name) {
        return new CarModel(name);
    }
}
