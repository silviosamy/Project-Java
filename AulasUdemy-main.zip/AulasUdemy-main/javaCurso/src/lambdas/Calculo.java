package lambdas;

public interface Calculo {

    double executar(double a, double b);
}
