package streams;

public class Map {
    public static void main(String[] args) {
//
//        Consumer<String> print = System.out::print;
//
//        List<String> marcas = Arrays.asList("BMW ", "Audi", " Honda");
////        Como aplicar o Map em Array:
//        marcas.stream().map(m -> m.toUpperCase()).forEach(print);
//        Buildar stream, mapear a Array, colocar tudo em maiúscula, e printar.


//        System.out.println("\n\nUsando composição");
//        marcas.stream()
//                .map(Utilitarios.maiuscula)
//                .map(Utilitarios.primeiraLetra)
//                .map(Utilitarios::grito)
//                .forEach(print);
    }
}

