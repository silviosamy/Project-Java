/**
 *
 */
/**
 *
 */
module javaCurso {
    requires java.sql;
    requires jdk.jshell;
    requires java.management;
    requires transitive mysql.connector.j;
}