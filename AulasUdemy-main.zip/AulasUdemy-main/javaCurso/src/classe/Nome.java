package classe;

public class Nome {

	String nome;
	String email;
}
