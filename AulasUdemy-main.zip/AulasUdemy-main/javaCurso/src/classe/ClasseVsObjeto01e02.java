package classe;

public class ClasseVsObjeto01e02 {
	public static void main(String[] args) {
		
//		Dentro do corpo da classe, existem Atributos e Comportamentos:
//		Atributos : Dados / Comportamentos : Métodos
//		Dados : Estrutura de Dados : Int/Boolean/date/String...
//		Método: Sentença de códigos. Ex: If, else, switch, for, etc.
//		Ambos são MEMBROS da classe. Neste caso: main

//		Aula02:
//		Classe define UM Tipo (Estrutura de dados)
//		a Classe define uma Abstração (simplificação)
//		Ex: Estoque de itens em um mercado. Classe Produto: Item ,preço, quantidade. Etc.
//		A partir de uma classe , tem os objetos(dados).
//		Ex: Acabei de instanciar 300 objetos do tipo Produto. 
//		A classe é um Molde. 
//		
//		Classe Produto;
//	    String Nome
//		double Preço
//		double Desconto
//		Construtor é o responsável que a partir de uma classe define novos objetos. (new Construtor).
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
	}
}
