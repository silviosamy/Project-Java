package classe;

public class ValoresPadroes {
	public static void main(String[] args) {
			}
}
// byte, short , int, longe -> 0
// float, double -> 0.0
// boolean -> False
// char -> '\u0000' Tabela UniCode.
// Objetos por padrão tem valor NULL (nulo).
// String tem o valor nulo se não for inserido nada (ou seja, não aponta para nada)