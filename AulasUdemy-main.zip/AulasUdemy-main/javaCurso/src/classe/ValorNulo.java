package classe;

public class ValorNulo {
	public static void main(String[] args) {
		
		String s1 = ""; //variável existe, como String, porém, sem valor definido.

		System.out.println(s1.concat("!!!!"));
		
//		Data d1 = null; //Não é possível acessar nem atributo, nem método de algo null.
//		d1.mes = 3; //A variável é um espaço de memória, podendo conter : Valor ou Endereço de memória
//		             que aponta para um endereço onde o objeto foi criado
//		Nenhuma expresão será verdadeira, se o valor for null.
//		if(d1 != null)
//			d1.mes = 3;
		
//		String s2 = null;

//		System.out.println(s2.concat("????"));
		
//		String s2; //Isso não existe. Deve-se atribuir um valor. 
	}
}
