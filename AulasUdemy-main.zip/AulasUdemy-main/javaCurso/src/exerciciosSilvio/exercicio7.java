package exerciciosSilvio;

public class exercicio7 {
    public static void main(String[] args) {
//        Faça um algoritmo que leia dois valores booleanos (lógicos)
//        e determine se ambos são VERDADEIRO ou FALSO.
        boolean x = true;
        boolean y = false;

        if (x && y ) {
            System.out.println("Ambos são verdadeiros");
        } else {
            System.out.println("Um é verdadeiro e outro é falso");
        }
    }
}
