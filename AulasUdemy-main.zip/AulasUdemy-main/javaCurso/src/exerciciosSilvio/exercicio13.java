package exerciciosSilvio;

public class exercicio13 {
    public static void main(String[] args) {
//        Faça algoritmo que leia o nome e a idade de uma pessoa e
//        imprima na tela o nome da pessoa e se ela é maior ou menor de idade.
        String nome = "Alencar ";
        int idade = 18;

        if (idade >= 18) {
            System.out.println(nome + "é maior de idade");
        } else {
            System.out.println(nome + "é menor de idade");
        }
    }
}
