package exerciciosSilvio;

public class exercicio4 {
//    Faça um algoritmo que receba um número inteiro
//    e imprima na tela o seu antecessor e o seu sucessor.
    public static void main(String[] args) {

        int n = 10;

        System.out.println(n - 1);
        System.out.println(n + 1);

    }
}
