package exerciciosSilvio;

public class exercicio10 {
    public static void main(String[] args) {
//Faça um algoritmo que leia três notas obtidas por um aluno, e imprima na tela a média das notas.

        double nota1 = 5.6;
        double nota2 = 7.5;
        double nota3 = 9.2;
        double media = (nota1 + nota2 + nota3) / 3;
        System.out.printf("%.2f", media);
    }
}
