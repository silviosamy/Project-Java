package exerciciosSilvio;

public class Exercicio6 {
    public static void main(String[] args) {
//Faça um algoritmo que leia um valor qualquer e imprima na tela com um reajuste de 5%.
        double valor = 120;
        double valorDesconto = (valor / 100) * 5;
        System.out.println(valor + valorDesconto);
    }
}


