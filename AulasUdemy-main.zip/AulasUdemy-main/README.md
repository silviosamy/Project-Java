## Hi there 👋

Nice to meet you! Im Silvio.

About me:

- 🌱 I’m currently learning Java on Udemy website throught a course. You can follow my progress on /AulasUdemy
- 👯 I’m looking to collaborate only in my own projects for now, currently learning Java/Spring Boot and SQL.
- 📫 You can reach me on Instagram @silviosamy
- PS: If you have anything that helps me, I'd be happy to listen.

