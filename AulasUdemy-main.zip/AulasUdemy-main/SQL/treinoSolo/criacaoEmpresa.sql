CREATE TABLE empresateste (
    cod_empresa BIGINT(20) AUTO_INCREMENT PRIMARY KEY,
    razao_social VARCHAR(100) NOT NULL,
    cnpj VARCHAR(14) NOT NULL
)